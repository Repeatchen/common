// components/details/details.js
Component({
    /**
     * 组件的属性列表
     */
    properties: {

    },

    /**
     * 组件的初始数据
     */
    data: {
        info:[{
            "name":"隐形眼镜",
            "type":3,
            "aipre":0,
            "explain":"干垃圾即其它垃圾，指除可回收物、有害垃圾、厨余垃圾（湿垃圾）以外的其它生活废弃物。",
            "contain":"常见包括砖瓦陶瓷、渣土、卫生间废纸、猫砂、污损塑料、毛发、硬壳、一次性制品、灰土、瓷器碎片等难以回收的废弃物",
            "tip":"尽量沥干水分；难以辨识类别的生活垃圾都可以投入干垃圾容器内"
            },]

    },

    /**
     * 组件的方法列表
     */
    methods: {
        cancelModel(){
            this.triggerEvent('cancelModel', false)
        }

    }
})
