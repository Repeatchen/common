// pages/setting/setting.js
Page({

    /**
     * 页面的初始数据
     */
    data: {
        configList: [
            {
                icon: '../../images/city.png',
                title: '切换城市',
                desc: '北京',
                page:'city'
            },
            {
                icon: '../../images/aboutUs.png',
                title: '关于我们',
                desc: '',
                page:'aboutUs'
            },
            // {
            //     icon: '../../images/feedback.png',
            //     title: '问题反馈',
            //     desc: '',
            //     page:''
            // },
            {
                icon: '../../images/admire.png',
                title: '鼓励开发者',
                desc: '',
                page:'admire'
            },
            {
                icon: '../../images/share.png',
                title: '分享给好友',
                desc: '',
                page:'share'
            },
        ]

    },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function (options) {

    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function () {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function () {

    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function () {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function () {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function () {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function () {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function () {

    },
    gotoPage(e){
        wx.navigateTo({
            url: '/pages/encourage/encourage', 
        })
    }
})