// miniprogram/pages/camera/camera.js
import request from "../../server/request";
Page({

    /**
     * 页面的初始数据
     */
    data: {
        imgBase64:'',
        src:'',
        disabledCamera:false,
        classificationList:''


    },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function (options) {

    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function () {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function () {

    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function () {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function () {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function () {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function () {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function () {

    },
    repeatPhoto(){
        this.setData({
            src: '',
            disabledCamera:false,
            classificationList:''
        });
    },
    takePhoto() {
        const ctx = wx.createCameraContext()
        ctx.takePhoto({
            quality: 'high',
            success: (res) => {
                this.setData({
                    src: res.tempImagePath,
                    disabledCamera:true
                });
                this.urlTobase64(res.tempImagePath);

            }
        })
    },
    urlTobase64(url) {
        wx.getFileSystemManager().readFile({
            filePath: url, //选择图片返回的相对路径
            encoding: 'base64', //编码格式
            success: res => { //成功的回调
                this.setData({
                    imgBase64:res.data
                })
                this.goAPI();
                console.log('data:image/png;base64,' + res.data)
            }
        })
       
        //   //以下两行注释的是同步方法，不过我不太喜欢用。
        //       //let base64 = wx.getFileSystemManager().readFileSync(res.tempFilePaths[0], 'base64') 
        //   //console.log(base64)
    },
    goAPI(){
        let params = {
            url: 'https://api.tianapi.com/txapi/imglajifenlei/index',
            data: {
                key: '35319a009af7e0fa38e006aaf4232077',
                img: this.data.imgBase64
            }
        }
        request(params).then(
            data => {
                data.newslist.map((item) => {
                    switch (item.lajitype) {
                        case 0:
                            item.background = 'blue';
                            item.stateName = '可用垃圾';
                            break;
                        case 1:
                            item.background = 'red';
                            item.stateName = '有害垃圾';
                            break;
                        case 2:
                            item.background = 'green';
                            item.stateName = '厨余垃圾';

                            break;
                        case 3:
                            item.background = 'black';
                            item.stateName = '其他垃圾';
                            break;

                    }
                })
                this.setData({
                    classificationList: data.newslist
                })
                console.log(data)
            },
            err => {
                console.log('H5调用增加次数接口失败！！')
            }
        );
    },
    error(e) {
        console.log(e.detail)
    }
})