// pages/classification/classification.js
import request from "../../server/request";

Page({

    /**
     * 页面的初始数据
     */
    data: {
        showDetails: false, //弹框显示
        curNav: 2,
        curIndex: 0,
        cateItems: [{
                id: 2,
                name: '厨余垃圾',
                enName: 'KISTCHEN WASTE',
                imgPath: '../../images/food_waste.png',
                background: 'green',
                children: []
            },
            {
                id: 0,
                name: '可回收物',
                enName: 'RECYCLABLE WASTE',
                background: 'blue',
                imgPath: '../../images/recoverable.png',
                children: []
            },
            {
                id: 1,
                name: '有害垃圾',
                enName: 'HAZARDOUS WASTE',
                background: 'red',
                imgPath: '../../images/harmful.png',
                children: []
            },
            {
                id: 3,
                name: '其他垃圾',
                enName: 'OTHER WASTE',
                background: 'black',
                imgPath: '../../images/other_waste.png',
                children: []
            }
        ]

    },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function (options) {
        this.switchRightTab();

    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function () {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function () {
        this.switchRightTab();

    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function () {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function () {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function () {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function () {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function () {

    },
    switchRightTab: function (e) {
        // 获取item项的id，和数组的下标值  
        let id = e ? e.target.dataset.id : this.data.curNav,
            index = e ? parseInt(e.target.dataset.index) : '';

        // 把点击到的某一项，设为当前index  
        this.setData({
            curNav: id,
            curIndex: index
        })

        let params = {
            url: 'https://api.tianapi.com/txapi/hotlajifenlei/index',
            data: {
                key: '35319a009af7e0fa38e006aaf4232077',
                type: id,
                date:'20200430'
            }
        }
        let cateItems = ''
        let cateItemsNew = this.data.cateItems;

        request(params).then(
            data => {
                cateItemsNew.map((item) => {
                    if(item.id === this.data.curNav){
                        item.children = data.newslist
                    }
                })
                this.setData({
                    cateItems: cateItemsNew
                })
                console.log(this.data.cateItems)

            },
            err => {
                
            }
        );


    },
    showDetails() {
        this.setData({
            showDetails: true
        })
    },
    cancelModel() {
        this.setData({
            showDetails: false
        })
    }
})