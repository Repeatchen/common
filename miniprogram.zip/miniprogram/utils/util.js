let api = require("../server/api.js");
const app = getApp()

let config = require('./config.js')
// 版本号比较
function compareVersion(v1, v2) {
    v1 = v1.split('.')
    v2 = v2.split('.')
    const len = Math.max(v1.length, v2.length)

    while (v1.length < len) {
        v1.push('0')
    }
    while (v2.length < len) {
        v2.push('0')
    }

    for (let i = 0; i < len; i++) {
        const num1 = parseInt(v1[i])
        const num2 = parseInt(v2[i])

        if (num1 > num2) {
            return 1
        } else if (num1 < num2) {
            return -1
        }
    }

    return 0
}

/* 
兼容判断处理
askedVersion是可选参数,可用来进一步判断不同版本中都存在但是有更新的方法
*/
function useOrUpdate(fun = () => {}, askedVersion = '') {
    const version = wx.getSystemInfoSync().SDKVersion
    const condition = askedVersion ? compareVersion(version, askedVersion) >= 0 : !!wx[fun]

    if (condition) {
        wx[fun]()
    } else {
        wx.showModal({
            title: '提示',
            content: '当前微信版本过低，无法使用该功能，请升级到最新微信版本后重试。'
        })
    }
}

// 格式化时间
function formatTime(date) {
    const year = date.getFullYear()
    const month = date.getMonth() + 1
    const day = date.getDate()
    const hour = date.getHours()
    const minute = date.getMinutes()
    const second = date.getSeconds()

    return {
        year,
        month,
        day,
        hour,
        minute,
        second
    }
}

// 个位数字补0
function formatNumber(n) {
    n = n.toString()
    return n[1] ? n : '0' + n
}

/* 倍数转换
@params
raw:需要处理的原始数据
base:转换倍数的基数
n:转换倍数的指数
isMultiply:是否是乘法转换

@result
返回值为符合小数显示规则的数字类型
小数显示规则：有两位小数展示两位，如果只有一位就只显示一位，如果没有就不显示
*/
function unitTransform(raw, base = 10, n = 3, isMultiply = false) {
    if (!raw || typeof + raw != 'number') {
        return 0
    }
    if (typeof + raw != 'number' || typeof + n != 'number') {
        base = 10
        n = 3
    }
    n = isMultiply ? n : -n
    let num = raw * Math.pow(base, n)
    let str = num.toFixed(2)
    // let str = num.substring(0, num.indexOf(".") + 3);
    return parseFloat(str)
}

/* 时间转换
@params
timestamp:时间戳
separation:分隔符
needTime:是否需要转换时分秒

@result
格式化后的字符串
*/
function timestampTransform(timestamp = 0, separation = '/', needTime = true) {
    if (typeof + timestamp != 'number') {
        return '-'
    }
    let time = new Date(timestamp)

    let {
        year,
        month,
        day,
        hour,
        minute,
        second
    } = formatTime(time)

    if (needTime) {
        return [year, month, day].map(formatNumber).join(separation) + ' ' + [hour, minute, second].map(formatNumber).join(':')
    } else {
        return [year, month, day].map(formatNumber).join(separation)
    }

    return str
}

// 分享小程序
function share(shareMsg = {}) {
    return {
        title: shareMsg.title || '欧了出行',
        path: shareMsg.path || '/pages/index/index',
        imageUrl: shareMsg.shareImg || 'https://oss.olayc.cn/1FEB124E9700BE5E55748F219D042C9D.png'
    }
}

// 高德地址解析
function addressResolve(address = []) {
    let [{
        desc = '',
        latitude = 0,
        longitude = 0,
        name = '',
        regeocodeData: {
            formatted_address = '',
            addressComponent: {
                adcode = '',
                citycode = '',
                country = '',
                province = '',
                city = '',
                district = '',
                township = ''
            }
        }
    }] = address || {}

    let addressObj = {
        name,
        desc,
        latitude,
        longitude,
        formatted_address,
        adcode,
        citycode,
        country,
        province,
        city,
        district,
        township
    }
    console.log('地址解析', addressObj)
    return addressObj
}

function getJsCode() {
    return new Promise((resolve, reject) => {
        wx.login({
            success: res => {
                resolve(res.code)
            },
            fail: err => {
                reject(err)
            },
            complete: err => {}
        })
    })
}

// 返回首页
function back2Index() {
    const pages = getCurrentPages()
    console.log('pages', pages)
    wx.navigateBack({
        delta: pages.length - 1
    })
}

function getInterDate(data) {
    let weekList = ['星期日', '星期一', '星期二', '星期三', '星期四', '星期五', '星期六']
    console.log(data)
    if (!data.startTime) {
        return
    }
    let chineseDay = ''
    let time = ''
    let date = new Date()
    console.log(myTime(data.startTime))
    let date1 = new Date(data.startTimeTimestamp)
    let date2 = new Date(data.endTimeTimestamp)
    console.log(date, '---', date1, '======', date2)
    let mounth = formatNumber(date1.getMonth() + 1)
    let day = formatNumber(date1.getDate())

    if (date.getDate() === date1.getDate()) {
        chineseDay = "今天"
    } else {
        chineseDay = "明天"

    }
    let week = weekList[date1.getDay()]; //获取周


    time = `${formatNumber(date1.getHours())}:${formatNumber(date1.getMinutes())}-${formatNumber(date2.getHours())}:${formatNumber(date2.getMinutes())} `

    return {
        chineseDay,
        time,
        mounth,
        day,
        week
    }
}

/*
 *   解析"2019-04-07T16:00:00.000+0000"; 时间格式
 */

function myTime(date) {
    var arr = date.split("T");
    var d = arr[0];
    var darr = d.split('-');

    var t = arr[1];
    var tarr = t.split('.000');
    var marr = tarr[0].split(':');

    var dd = parseInt(darr[0]) + "/" + parseInt(darr[1]) + "/" + parseInt(darr[2]) + " " + parseInt(marr[0]) + ":" + parseInt(marr[1]) + ":" + parseInt(marr[2]);
    return dd;
}

function getUrlParam(url, name) {
    var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)");
    var arr = decodeURIComponent(url).split("?")
    console.log(arr)
    if (arr.length = 1) return null
    var r = arr[1].match(reg);
    if (r != null) return decodeURI(r[2]);
    return null;
}

function getUrlAllParam(url, b) {
    if (!url) {
        return
    }
    var index = url.indexOf('?')
    var str = url.substring(index + 1)
    var arr = str.split('&')
    var obj = {}
    for (var i = 0; i < arr.length; i++) {
        var arr1 = arr[i].split('=')
        obj[arr1[0]] = arr1[1]
    }
    if (obj[b]) {
        return obj[b]
    } else {
        return null
    }
}

function getUrl(url) {
    if (!url) {
        return
    }
    var index = url.indexOf('?')
    if (index > 0) {
        var str = url.substring(0, index)

    } else {
        str = url
    }
    return str
}

function setToken(options = {}) {
    // 截至2019.12.24 现有sotrage中存储数据有token userId userMobile,所以针对活动跳转充值设置token这3个参数为必传，否则可能影响现有业务
    if (!options.token || !options.userId || !options.userMobile) {
        console.warn("无法设置token,token、userId、userMobile必传", options)
        return false;
    }
    if (!!wx.getStorageSync('_token')) {
        wx.showToast({
            icon: "none",
            title: '小程序登陆用户更新为：' + asteriskMobile(options.userMobile),
            duration: 5000
        })
    }
    console.log("设置token:" + options.token)
    wx.setStorageSync('_token', options.token)
    wx.setStorageSync('userId', options.userId)
    wx.setStorageSync('userMobile', asteriskMobile(options.userMobile))
}
// 安全域名校验
function isSecureDomain(link) {
    let result = config.SECURE_DOMAIN.filter(item => {
        console.log(link.indexOf(item))
        return link.indexOf(item) > 0 && link.indexOf(item) < 30
    })
    return result.length > 0
}
// 手机号脱敏
function asteriskMobile(mobile) {
    return mobile.toString().replace(/(\d{3})\d{4}(\d{4})/, '$1****$2')
}

function findFromArr(arr, key) {
    return arr.filter(item => {
        return item.hasOwnProperty(key)
    })
}
// 从postMessage数据中查找，返回第一个查找到的数据
function getFromArr(arr, key) {
    var resultArr = findFromArr(arr, key)
    return resultArr.length == 0 ? null : resultArr[0][key]
} // 从postMessage数据中查找，返回第一个查找到的数据
function getLastFromArr(arr, key) {
    var resultArr = findFromArr(arr, key)
    return resultArr.length == 0 ? null : resultArr[resultArr.length - 1][key]
}
// 阿里云日志
function logger(logger = [], tracker = {}, trace = {}) {
    if (api.env != 'prod') {
        return
    }
    if (!logger.push || !logger.logger) {
        console.log('阿里云日志上报失败，请检查日志上报的第一个参数是否为app.tracker')
        return
    }
    Object.assign(tracker, trace)
    logger.push('_systemInfo', JSON.stringify(tracker))
    logger.logger();
}

// 清除未登录状态下积压的请求队列
function clearRequestQueue(flag = 'fail', result = '') {
    // console.log('登录结束，'状态变成不在登录中')
    app.globalData.isLogining = false;

    if (flag == 'success') {
        // console.log('登录成功，依次把requestQueue中的每个请求拿出来，执行请求的resolve，把token传进去')
        while (app.globalData.requestQueue.length) {
            app.globalData.requestQueue.shift().resolve(result);
        }
    } else {
        // console.log('登录失败，依次把requestQueue中的每个请求拿出来，执行请求的reject，把err传进去')
        while (app.globalData.requestQueue.length) {
            app.globalData.requestQueue.shift().reject(result);
        }
    }
}

// 拨打虚拟电话
function makePhoneCall(mobile, callNumber) {

    wx.showModal({
        title: '号码保护中',
        content: `平台将对您的手机号进行加密呼出${mobile}`,
        cancelText: '取消',
        confirmText: '立即拨打',
        confirmColor: '#14A83E',
        success: (res) => {
            if (res.confirm) {
                wx.makePhoneCall({
                    phoneNumber: callNumber ? callNumber : mobile
                })
            }
        }
    })
}
// 直接拨打电话没有第二次弹框
function phoneCall(mobile, callNumber) {
    wx.makePhoneCall({
        phoneNumber: callNumber ? callNumber : mobile
    })
}

// 去掉城市名中的市
function formatCityName(city) {
    if (!city) {
        return ''
    }

    let length = city.length

    if (length) {
        city = city[length - 1] == '市' ? city.substring(0, length - 1) : city
        return city
    } else {
        return ''
    }
}

// 存放firstLogin，followed字端在globalData
function setFirstLoginAndFollowed(data) {
    // 0是新用户 1是老用户
    app.globalData.isFirstLogin = data.firstLogin && data.firstLogin == 0 ? true : false;
    // 0是未关注 1是已关注
    app.globalData.isFollowed = data.followed && data.followed == 1 ? true : false;
    app.globalData.showBottomLogin = data.token ? false : true;
}

// 是否为今天
function isToday(str) {
    return new Date().getTime() - new Date(str).getTime() < 86400000;
}

//判断时间差(分钟)
function timeDifference(time1, time2) {
    //判断开始时间是否大于结束日期
    if (time1 > time2) {
        console.log("开始时间不能大于结束时间！");
        return false;
    }

    //截取字符串，得到日期部分"2009-12-02",用split把字符串分隔成数组
    var begin1 = time1.substr(0, 10).split("-");
    var end1 = time2.substr(0, 10).split("-");

    //将拆分的数组重新组合，并实例成化新的日期对象
    var date1 = new Date(begin1[1] + - +begin1[2] + - +begin1[0]);
    var date2 = new Date(end1[1] + - +end1[2] + - +end1[0]);

    //得到两个日期之间的差值m，以分钟为单位

    //Math.abs(date2-date1)/1000/60得到以分钟为单位的差值
    var m = parseInt(Math.abs(date2 - date1) / 1000 / 60);

    //小时数和分钟数相加得到总的分钟数
    //time1.substr(11,2)截取字符串得到时间的小时数
    //parseInt(time1.substr(11,2))*60把小时数转化成为分钟
    var min1 = parseInt(time1.substr(11, 2)) * 60 + parseInt(time1.substr(14, 2));
    var min2 = parseInt(time2.substr(11, 2)) * 60 + parseInt(time2.substr(14, 2));

    //两个分钟数相减得到时间部分的差值，以分钟为单位
    var n = min2 - min1;

    //将日期和时间两个部分计算出来的差值相加，即得到两个时间相减后的分钟数
    var minutes = m + n;
    return minutes
}

module.exports = {
    compareVersion,
    useOrUpdate,
    formatTime,
    unitTransform,
    timestampTransform,
    share,
    addressResolve,
    getJsCode,
    getInterDate,
    back2Index,
    getUrlParam,
    getUrlAllParam,
    getUrl,
    setToken,
    isSecureDomain,
    asteriskMobile,
    findFromArr,
    getFromArr,
    getLastFromArr,
    logger,
    clearRequestQueue,
    makePhoneCall,
    phoneCall,
    formatCityName,
    isToday,
    timeDifference,
    setFirstLoginAndFollowed,

}