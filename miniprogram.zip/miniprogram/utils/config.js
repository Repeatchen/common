// 小程序版本
const VERSION = '1.9.4'
// 地图key
const MAPKEY = '26afff30983e4b7bfa670e7972c4c22a'
// 自定义地图key
const SUBKEY = '5YQBZ-6O5RD-IL344-H3D42-464E2-NXBHO'
// 地图默认缩放比
const SCALE = 17
// 车辆扫描时间间隔
const SCANTIMER = 10000
// 订单轮询时间间隔
const POLLTIMER = 5000
// 异常上报
const ERRREPORTAPI = 'https://dev-oleyc-frontend.olayc.cn/v.gif'
// 异常上报项目ID
const ERRREPORTID = '29a76c9fa6f0e3055a91a2a51f36a92c'
// 授权传token的广告图域名
const SECURE_DOMAIN = [
    "activity.dev.olayc.cn",
    "activity.test.olayc.cn",
    "uat-activity.olayc.cn",
    "activity.olayc.cn",
]

module.exports = {
  VERSION,
  MAPKEY,
  SUBKEY,
  SCALE,
  SCANTIMER,
  POLLTIMER,
  ERRREPORTAPI,
  ERRREPORTID,
    SECURE_DOMAIN
}