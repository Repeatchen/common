function getApiPrefixList(env) {
    let baseList = {
        order: '',
        mp: '',
        uc: '',
        coupon: '',
        activity: '',
        wallet: '',
    }

    for (let key in baseList) {
        if (env === 'dev' || env === 'test' || env === 'uat') {
            baseList[key] = `https://proxy-${env}.olayc.cn/${key}`
        } else if (env === 'test2') {
            baseList[key] = `https://${env}-proxy.olayc.cn/${key}`
        } else if (env === 'prod') {
            baseList[key] = `https://${key}.api.olayc.cn/${key}`
        }
    }

    // 处理域名和服务名不对应的情况
    if (env === 'dev' || env === 'test' || env === 'uat') {
        baseList.evaluation = `https://proxy-${env}.olayc.cn/eval`
        baseList.pay = `https://proxy-${env}.olayc.cn/olayc/pay`
        baseList.carpooling = `https://proxy-${env}.olayc.cn/carpooling`
        baseList.audio = `https://proxy-${env}.olayc.cn/magic-tools/audio`
        // 原始接口为 http://polaris.api.dev.olayc.cn
        baseList.common = `https://proxy-${env}.olayc.cn/common`

    } else if (env === 'test2') {
        baseList.evaluation = `https://${env}-proxy.olayc.cn/eval`
        baseList.pay = `https://${env}-proxy.olayc.cn/pay`
        baseList.carpooling = `https://${env}-proxy.olayc.cn/carpooling`
        baseList.audio = `https://${env}-proxy.olayc.cn/magic-tools/audio`
        baseList.common = `https://${env}-proxy.olayc.cn/common`


    } else if (env === 'prod') {
        baseList.evaluation = `https://eval.api.olayc.cn/eval`
        baseList.pay = `https://pay.api.olayc.cn/olayc/pay`
        baseList.carpooling = `https://car-pooling.api.olayc.cn/carpooling`
        baseList.audio = `https:/magic-tools.api.olayc.cn/audio`
        baseList.common = `https://polaris.api.olayc.cn/common`

    }

    return baseList
}

function getH5UrlPrefixList(env) {
    let baseList = {
        h5: '',
        activity: '',
        mp: ''
    }

    for (let key in baseList) {
        if (env === 'dev' || env === 'test' || env === 'text2') {
            console.log(baseList[key], 'text2', `https://${env}-${key}.olayc.cn`)
            if (key == 'h5') {
                baseList[key] = `https://${key}.${env}.olayc.cn`
            } else {
                baseList[key] = `https://${env}-${key}.olayc.cn`
            }
        } else if (env === 'uat') {
            baseList[key] = `https://${env}-${key}.olayc.cn`
        } else if (env === 'prod') {
            baseList[key] = `https://${key}.olayc.cn`
        }
    }

    return baseList
}


module.exports = {
    getApiPrefixList,
    getH5UrlPrefixList
}