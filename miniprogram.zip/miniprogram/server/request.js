let request = async function ({
  url = "",
  methods = "POST",
  contentType = "application/x-www-form-urlencoded",
  data = {},
}) {
  console.log({
    url,
    methods,
    contentType,
    data,
  })

  return new Promise(async (resolve, reject) => {
    wx.request({
      url,
      method: methods,
      data,
      header: {
        "content-type": contentType
      },
      success: async res => {
        let code = res && res.data.code;
        let resData = res && res.data;
        if (code === 200) {
          resolve(resData);
        } else {
          reject(res)

        }
      },
      fail: async err => {
        reject({
          code: err.data.code,
          msg: `网络错误:${err.data.msg}`
        });

      },
      complete: res => {}
    });
  })
};


module.exports = request;