let {
    getApiPrefixList,
    getH5UrlPrefixList
} = require("./env.js");

let env = "dev" 
// let env = "test"
// let env = "test2"
// let env = "uat"
// let env = 'prod'

let apiPrefixList = getApiPrefixList(env);
let h5UrlPrefixList = getH5UrlPrefixList(env);

let {
    order,
    mp,
    uc,
    pay,
    evaluation,
    coupon,
    activity,
    carpooling,
    audio,
    wallet,
    common,
} = apiPrefixList

let {
    activity: activityDomin,
    mp: mpDomin
} = h5UrlPrefixList

let api = {
    env,
    // 查询当前城市开通的服务类型
    queryCityServiceType: common + "/order/queryBusinessLine",
    // 更新乘客城市属性
    updatePassengerCity: uc + "/v1/updatePassengerCity",
    // 首页弹窗
    advertisement: activity + "/advertise/v1/getAdvertisePopupDesc",
    // autoPay
    autoPay: wallet + "/v1/info/autopay",
    // 快速登录
    quickLogin: mp + "/v1/wechat/user/sso",
    // 获取上车点电子围栏
    queryEnclosureList: carpooling + "/order/select/queryEnclosureList",
    // 赵权包的钱包充值接口
    rechargeMp: mp + "/v1/wechat/pay/initRechargeSign",
    // 钱包充值
    rechargeWallet: wallet + "/v1/recharge",
    // 乘车人列表
    carPersonList: uc + "/passenger/v1/select",
    // 删除乘车人
    delCarPerson: uc + "/passenger/v1/delete",
    // 添加乘车人
    addCarPerson: uc + "/passenger/v1/insert",
    // 查看充值规则
    getRechargeList: wallet + "/v1/rechargeRuleList",
    // 查看账户明细
    getAccoundDetail: wallet + "/v1/record/app",
    // 查看钱包详情
    getWalletDetail: wallet + "/v1/info/app",
    // 查看定位点是否已经开通服务
    getAddressServer: order + "/v2/checkCityOpen",
    // 获取已经开通城市的列表
    getCityList: mp + "/v1/wechat/cf/getCities",
    // 获取用户信息
    getUserMessage: mp + "/v1/wechat/user/getUserWechatInfo",
    // 上传头像用户授权信息
    upUserImg: mp + "/v1/wechat/user/updateUserInfo",
    // 下单接口
    placeOrder: order + "/v3/createTrip",
    // 行程估价
    getEstimate: order + "/v4/segmentValuation",
    // 根据手机号登陆
    phoneLogin: mp + "/v1/wechat/user/loginWithCode",
    // 查询专车是否有进行中的订单
    getPeopleOrder: order + "/v3/appStartQuery",
    // 提示关注小弹框
    appStartQuery: carpooling + "/order/select/appStartQuery",
    // 查询已开通城市
    getCity: uc + "/v1/getOpenCities",
    // 向乘客发送验证码
    sendSmsCode: uc + "/v1/sendSmsCode",
    // 查询城市是否已开通
    checkCityOpen: order + "/v1/checkCityOpen",
    // 查询附近车辆
    queryCarByPosition: order + "/v2/queryCarByPosition",
    // 微信登陆以后拿 加密数据换取手机号
    getUserPhone: mp + "/v1/wechat/user/login",
    // 查询推荐下车点
    getRecommendDestAddress: order + "/v1/recommendDestAddress",
    // 查询推荐下车点
    getCarpoolRoute: carpooling + "/order/select/queryLineCityList",
    // 拼车查询下车点城市
    queryLineOpenCityList: carpooling + "/order/select/queryLineOpenCityList",

    // 取消呼叫
    cancelCall: order + "/v1/cancelCall",
    // 重复呼叫
    tripRepeat: order + "/v1/tripRepeat",
    // 取消订单
    cancelOrder: order + "/v1/cancelOrder",
    //派单查询
    sendTripOrderStatus: order + "/v4/sendTripOrderStatus",
    //获取司机信息和车辆信息
    getDriverAndCarDetail: order + "/v1/getDriverAndCarDetil",
    //查询支付详情
    getPayDetail: order + "/v1/getPayDetil",
    // 预支付
    prePay: pay + "/v1/prePayOperation",
    // 获取微信支付所需的参数
    getWxSign: mp + "/v1/wechat/pay/initWxSign",
    // 支付
    pay: pay + "/v1/pay",
    // 支付状态检查
    getPayInfo: pay + "/v1/getPayinfo",
    //支付返券提示（不用了）
    giveCouponCue: order + "/v1/giveCouponCue",
    //乘客提交对本次行程的评价
    passengerEvaluation: evaluation + "/v1/passengerEvaluation",
    // 获取乘客提交的评价
    getEvaluations: evaluation + "/v1/getEvaluations",
    //查询乘客个人信息
    getPassenger: uc + "/v1/getPassenger",
    // 查询订单是否已评价
    hasEvaluation: mp + "/v1/wechat/eval/getEvaluation",
    //乘客查询紧急联系人
    getEmergencyContacts: uc + "/v1/emergency/getEmergencyContacts",
    //乘客添加紧急联系人
    addEmergencyContact: uc + "/v1/emergency/addEmergencyContact",
    //乘客删除紧急联系人
    deleteEmergencyContact: uc + "/v1/emergency/deleteEmergencyContact",
    //报警信息保存
    callPolice: order + "/v1/callPolice",
    //查询用户优惠券列表
    getUserCouponListByUserId: coupon + "/v1/getUserCouponListByUserIdForMobile",
    //兑换码领取优惠券
    attendExchangeActivity: activity + "/v1/attendExchangeActivity",
    // formId上传
    uploadFormId: mp + "/v1/wechat/msg/uploadFormId",
    // 乘客行程历史（order）
    getPassengerTrips: uc + "/v3/passengerTrips",
    // 用户钱包详情
    getWalletDetail: wallet + "/v1/info/app",
    // 路径规划
    getDrivingPath: mp + "/v1/wechat/car/drivingpath",
    // 评价标签
    getPassengerEval: evaluation + "/v2/passenger/getPassengerEval",

    // 检查是否展示添加到我的小程序
    checkCollect: mp + "/v1/wechat/user/tps",

    // 拼车业务
    // 创建订单
    intercityCreateTrip: carpooling + "/order/intercityCreateTrip",
    // 估价
    queryIntercityValuation: carpooling + "/order/queryIntercityValuation",
    // 取消订单
    cancelOrder: carpooling + "/order/cancel",
    // 城际订单列表
    tripList: carpooling + "/order/select/tripList",
    // 拔打电话
    callToDirver: carpooling + "/order/callToDirver",
    // 乘车时间列表
    queryIntercityBusTimeList: carpooling + "/order/queryIntercityBusTimeList",
    // 当前位置是否开通拼车
    queryIntercityIsOpen: carpooling + "/order/queryIntercityIsOpen",
    // 订单司机车辆信息
    driverCarInfo: carpooling + "/order/driverCarInfo",
    // 订单支付
    intercityPay: carpooling + "/order/pay",
    // 订单状态轮询
    queryIntercityOrderInfo: carpooling + "/order/queryIntercityOrderInfo",
    // 运营线路获取
    wayForCity: carpooling + "/order/select/wayForCity",
    // 拼车订单轮训
    getInterOrderInfo: carpooling + "/order/select/queryIntercityOrderInfo",
    // 拼车获取 订单司机信息
    getInterDriverInfo: carpooling + "/order/select/driverCarInfo",
    // 拼车虚拟电话拨打
    getInterFictitiousMobile: carpooling + "/order/select/callToDriver",
    // 拼车订单取消
    cancelInterOrder: carpooling + "/order/cancel",
    // 拼车支付信息获取
    getInterOrderPayInfo: carpooling + "/order/pay",
    // 拼车支付结果查询
    getInterPayResultInfo: carpooling + "/order/select/queryPayStatus",
    // 拼车查询用车时间在相差3个发车间隔内的订单
    getIntervalNearOrder: carpooling + "/order/select/queryIntervalNearOrder",

    // 摇一摇开通城市
    queryShakeAdCode: order + "/v1/queryYaoAdCode",
    getXunfeiResult: audio + "/query",
    uploadMp3: audio + "/uploadMp3",
    // 拼车订单轮训
    getInterOrderInfo: carpooling + "/order/select/queryIntercityOrderInfo",
    // 拼车获取 订单司机信息
    getInterDriverInfo: carpooling + "/order/select/driverCarInfo",
    // 拼车虚拟电话拨打
    getInterFictitiousMobile: carpooling + "/order/select/callToDriver",
    // 拼车订单取消
    cancelInterOrder: carpooling + "/order/cancel",
    // 拼车支付信息获取
    getInterOrderPayInfo: carpooling + "/order/pay",
    // 拼车支付结果查询
    getInterPayResultInfo: carpooling + "/order/select/queryPayStatus",
    // 查询拼车路线
    matchLine: carpooling + "/order/select/matchLine",
    // 判断起点是否在围栏内
    originCheckPoint: carpooling + "/order/select/originCheckPoint",

    // 杨招 新出租 估价接口
    getValuationInfo: order + "/newTaxi/valuation",
    // 杨招 新出租 创建订单接口
    postCreateTrip: order + "/newTaxi/createTrip",
    // 杨招 新出租 检查二维码接口
    qrCodeIsValid: order + "/newTaxi/qrCodeIsValid",

    // 获取什么是拼车的标题和url
    getLineTitle: carpooling + "/order/select/getLineTitle",

    // 高德接口转发
    getRegeo: mp + "/gaode/v3/geocode/regeo",
    getSubPOI: mp + "/gaode/v3/place/text",
    getInputTips: mp + "/gaode/v3/assistant/inputtips",

    // h5url
    h5cancelPenalties: `${mpDomin}/passenger/cancelPenalties.html#/index`,
    h5billDetail: `${mpDomin}/passenger/mileageValuation.html#/expensesDetail`,
    h5valuationDetail: `${mpDomin}`,
    h5CardShop: `${mpDomin}/passenger/couponPackage.html#/index`,

    h5interCityIntroduce: `${mpDomin}/passenger/whatsCarpool.html#/`,
    h5interCitycancelReason: `${mpDomin}/passenger/cancelPenalties.html#/reason`,
    h5PassengerInviteFriends: `${activityDomin}/passengerInviteFriends.html#/channel501`,


    h5activity: `${activityDomin}`,
};

module.exports = api;